#https://github.com/anthonynorth/rscodeio/blob/master/README.md

install.packages("remotes")
library(remotes)
remotes::install_github("anthonynorth/rscodeio")
rscodeio::install_theme()